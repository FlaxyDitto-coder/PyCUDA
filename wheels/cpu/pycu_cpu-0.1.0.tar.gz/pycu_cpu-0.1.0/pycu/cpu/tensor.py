class Tensor:
    def __init__(self, data):
        self.data = data
        self.shape = self._shape(data)

    def _shape(self, d):
        if not isinstance(d, list):
            return ()
        if len(d) == 0:
            return (0,)
        return (len(d),) + self._shape(d[0])

    def tolist(self):
        return self.data

    def _apply_elementwise(self, other, op):
        if not isinstance(other, Tensor):
            return Tensor(self._apply_scalar(self.data, other, op))
        if self.shape != other.shape:
            raise ValueError('shape mismatch')
        return Tensor(self._apply_list(self.data, other.data, op))

    def _apply_scalar(self, data, scalar, op):
        if not isinstance(data, list):
            return op(data, scalar)
        return [self._apply_scalar(x, scalar, op) for x in data]

    def _apply_list(self, a, b, op):
        if not isinstance(a, list):
            return op(a, b)
        return [self._apply_list(x, y, op) for x, y in zip(a, b)]

    def __add__(self, other):
        return self._apply_elementwise(other, lambda x,y: x+y)

    def __mul__(self, other):
        return self._apply_elementwise(other, lambda x,y: x*y)

    def matmul(self, other):
        if len(self.shape) != 2 or len(other.shape) != 2:
            raise ValueError('matmul requires 2D tensors')
        a = self.data
        b = other.data
        m = len(a)
        n = len(b[0])
        p = len(b)
        res = [[sum(a[i][k]*b[k][j] for k in range(p)) for j in range(n)] for i in range(m)]
        return Tensor(res)
