from .cpu.tensor import Tensor as CPUTensor
from .cuda import cuda_available, get_cuda_version, CUDATensor

def tensor(data, device='cpu'):
    if device == 'cpu':
        return CPUTensor(data)
    elif device == 'cuda':
        if cuda_available():
            return CUDATensor(data)
        raise RuntimeError('CUDA not available')
    else:
        raise ValueError('unknown device')

__all__ = ['tensor', 'CPUTensor', 'CUDATensor', 'cuda_available', 'get_cuda_version']
