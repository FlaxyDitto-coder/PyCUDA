import ctypes
import sys

_lib = None
def _load_lib():
    global _lib
    if _lib is not None:
        return _lib
    candidates = []
    if sys.platform.startswith('win'):
        candidates = ['nvcuda.dll']
    elif sys.platform.startswith('darwin'):
        candidates = ['libcuda.dylib']
    else:
        candidates = ['libcuda.so', 'libcuda.so.1']
    for name in candidates:
        try:
            _lib = ctypes.CDLL(name)
            return _lib
        except OSError:
            continue
    return None

def cuda_available():
    lib = _load_lib()
    if not lib:
        return False
    cuInit = getattr(lib, 'cuInit', None)
    if cuInit:
        try:
            cuInit(0)
            return True
        except Exception:
            return False
    gv = getattr(lib, 'cuDriverGetVersion', None)
    if gv:
        try:
            ver = ctypes.c_int()
            gv(ctypes.byref(ver))
            return True
        except Exception:
            return False
    return False

def get_cuda_version():
    lib = _load_lib()
    if not lib:
        return None
    gv = getattr(lib, 'cuDriverGetVersion', None)
    if gv:
        try:
            ver = ctypes.c_int()
            gv(ctypes.byref(ver))
            return ver.value
        except Exception:
            return None
    return None

class CUDATensor:
    def __init__(self, data):
        raise NotImplementedError('CUDATensor is a stub; full CUDA support requires native bindings')
