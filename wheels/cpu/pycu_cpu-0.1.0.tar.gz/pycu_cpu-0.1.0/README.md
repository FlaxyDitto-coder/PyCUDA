PyCU
====

Minimal PyCU: a small pure-Python scaffold showing a CPU tensor implementation
and a lightweight CUDA detection stub. This repo is a starting point — a full
PyTorch replacement is out of scope for a single scaffold and requires native
bindings and drivers.

Quick usage
-----------

1. Install locally for development:

```bash
python -m pip install --upgrade build
python -m build
pip install dist/PyCU-0.1.0-py3-none-any.whl
```

2. Use the library:

```python
from pycu import tensor, cuda_available, get_cuda_version

print('cuda available:', cuda_available())
print('cuda version:', get_cuda_version())

T = tensor([[1,2],[3,4]], device='cpu')
S = tensor([[5,6],[7,8]], device='cpu')
print('matmul:', T.matmul(S).tolist())
```

Publishing to PyPI
------------------

- I cannot use or upload with credentials you provided. Do NOT share tokens.
- To publish yourself, build the package and upload with twine:

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine upload dist/* -u __token__ -p <YOUR_TOKEN_HERE>
```

If you want separate PyPI package names (`PyCU-CPU` and `PyCU-CUDA`), change
the `name` field in `pyproject.toml` before building.

Publishing `pycu-cpu` and `pycu-cuda`
----------------------------------

This repo can be published as two separate PyPI packages while keeping the
import name as `pycu` (the distribution name and import package name are
independent). Two sample pyproject files are provided: `pyproject_cpu.toml`
and `pyproject_cuda.toml`.

Build and upload `pycu-cpu`:

```powershell
# switch to cpu pyproject
copy pyproject_cpu.toml pyproject.toml /Y
python -m build
# set env vars securely before upload
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = "<YOUR_TOKEN>"
python -m twine upload --repository pypi --verbose dist/*
```

Build and upload `pycu-cuda`:

```powershell
# switch to cuda pyproject
copy pyproject_cuda.toml pyproject.toml /Y
python -m build
# set TWINE_USERNAME/TWINE_PASSWORD as above
python -m twine upload --repository pypi --verbose dist/*
```

Important: create a fresh PyPI API token for each upload (do not reuse the
exposed token), use `__token__` as the username and the token string as the
password, and never paste tokens into public chat.
